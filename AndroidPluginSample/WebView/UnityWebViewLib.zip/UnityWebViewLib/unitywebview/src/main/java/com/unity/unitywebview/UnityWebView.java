package com.unity.unitywebview;

import com.unity3d.player.UnityPlayer;

import android.media.Image;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.ProgressBar;

//For build release
//gradlew assembleRelease
public class UnityWebView {

    private static FrameLayout mFrameLayout;
    private static WebView mWebView;
    private static ImageView loadingView;


    public static void Init()
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable()
        {
            public void run()
            {
                if (mWebView != null)
                {
                    return;
                }
                String packageName = UnityPlayer.currentActivity.getApplicationContext().getPackageName();

                //framelayout
                if (mFrameLayout == null)
                {
                    mFrameLayout = new FrameLayout(UnityPlayer.currentActivity);
                    UnityPlayer.currentActivity.addContentView(
                            mFrameLayout,
                            new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                }
                mFrameLayout.setVisibility(View.GONE);

                //webview
                mWebView = new WebView(UnityPlayer.currentActivity);
                mWebView.setFocusable(true);
                mWebView.setFocusableInTouchMode(true);
                mWebView.setWebChromeClient(new WebChromeClient() {
                    public void onProgressChanged(WebView view, int progress) {
                        if (progress < 100) {
                            if (loadingView != null)
                            {
                                loadingView.setRotation((float) 3600 / 100 * progress);
                            }
                        } else {
                            if (loadingView != null)
                            {
                                loadingView.setVisibility(View.GONE);
                            }
                        }
                    }

                    public void onCloseWindow(WebView view){
                        super.onCloseWindow(view);
                        SetVisibility(false);
                    }
                });
                mWebView.setWebViewClient(new WebViewClient() {
                    @SuppressWarnings("deprecation")
                    @Override
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        super.onReceivedError(view, errorCode, description, failingUrl);
                    }
                });
                WebSettings mWebSettings = mWebView.getSettings();
                mWebSettings.setSupportZoom(false);
                mWebSettings.setJavaScriptEnabled(true);
                FrameLayout.LayoutParams mWebViewParams = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.NO_GRAVITY);
                //Add in the order, the later add, the upper shown
                mFrameLayout.addView(mWebView, mWebViewParams);

                //label background
                ImageView labelBg = new ImageView(UnityPlayer.currentActivity);
                labelBg.setBackgroundResource(UnityPlayer.currentActivity.getResources().getIdentifier("webview_labelbg", "drawable", packageName));
                FrameLayout.LayoutParams labelBgParams = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                labelBgParams.topMargin = 0;
                mFrameLayout.addView(labelBg, labelBgParams);

                //label
                ImageView label = new ImageView(UnityPlayer.currentActivity);
                label.setBackgroundResource(UnityPlayer.currentActivity.getResources().getIdentifier("webview_label", "drawable", packageName));
                FrameLayout.LayoutParams labelParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                labelParams.topMargin = 20;
                mFrameLayout.addView(label, labelParams);

                //close button
                Button closeBtn = new Button(UnityPlayer.currentActivity);
                closeBtn.setBackgroundResource(UnityPlayer.currentActivity.getResources().getIdentifier("webview_close", "drawable", packageName));
                closeBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        SetVisibility(false);
                    }
                });
                FrameLayout.LayoutParams closeBtnParams = new FrameLayout.LayoutParams(50, 50, Gravity.RIGHT);
                closeBtnParams.topMargin = 30;
                closeBtnParams.rightMargin = 30;
                mFrameLayout.addView(closeBtn, closeBtnParams);

                //loading
                loadingView = new ImageView(UnityPlayer.currentActivity);
                loadingView.setBackgroundResource(UnityPlayer.currentActivity.getResources().getIdentifier("webview_loading", "drawable", packageName));
                FrameLayout.LayoutParams loadingViewParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                loadingViewParams.topMargin = 200;
                mFrameLayout.addView(loadingView, loadingViewParams);
            }
        });
    }

    public static void LoadURL(final String url)
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable()
        {
            public void run()
            {
                if (mWebView == null)
                {
                    return;
                }
                //mWebView.loadUrl("about:blank"); //clear content
                mWebView.loadUrl(url);
                loadingView.setVisibility(View.VISIBLE);
            }
        });
    }

    public static void SetVisibility(final boolean visibility)
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable()
        {
            public void run()
            {
                if (mWebView == null)
                {
                    return;
                }
                if (visibility)
                {
                    mFrameLayout.setVisibility(View.VISIBLE);
                    mFrameLayout.requestFocus();
                    mWebView.requestFocus();
                }
                else
                {
                    mFrameLayout.setVisibility(View.GONE);
                    mWebView.loadUrl("about:blank");
                }
            }
        });
    }

}
