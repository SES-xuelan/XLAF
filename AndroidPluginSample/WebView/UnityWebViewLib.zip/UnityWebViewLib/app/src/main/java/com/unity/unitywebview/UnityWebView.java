package com.unity.unitywebview;

import com.unity3d.player.UnityPlayer;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

//For build release
//gradlew assembleRelease
public class UnityWebView {

    private static FrameLayout mFrameLayout;
    private static WebView mWebView;
    private static ImageView loadingView;

    private static String loadFailUrl = "about:blank";
    private static TextView loadFailTitle;
    private static TextView loadFailMessage;
    private static Button loadFailRetryButton;

    private static boolean pageLoading;
    private static String unityReceiver = "AY_WebViewHelper";

    //https://github.com/gree/unity-webview
    public static void Init(String mUnityReceiver)
    {
        if (mUnityReceiver != null && mUnityReceiver.length() > 0)
        {
            unityReceiver = mUnityReceiver;
        }

        InitUIWithPixels();
    }

    public static void LoadURL(final String url)
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable() {
            public void run() {
                if (mWebView == null) {
                    return;
                }

                //mWebView.loadUrl("about:blank"); //clear content
                mWebView.loadUrl(url);

                SetFailPageVisibility(false);
                mWebView.setVisibility(View.VISIBLE);
            }
        });
    }

    public static void PostURL(final String url, final String rtParams)
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable()
        {
            public void run()
            {
                if (mWebView == null)
                {
                    return;
                }

                //mWebView.loadUrl("about:blank"); //clear content
                String postData = String.format("rt=%s", rtParams);
                mWebView.postUrl(url, postData.getBytes());

                SetFailPageVisibility(false);
                mWebView.setVisibility(View.VISIBLE);
            }
        });
    }

    public static void SetVisibility(final boolean visibility)
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable() {
            public void run() {
                if (mWebView == null) {
                    return;
                }
                SetFailPageVisibility(false);

                if (visibility) {
                    mFrameLayout.setVisibility(View.VISIBLE);
                    mFrameLayout.bringToFront();
                    mFrameLayout.requestFocus();
                    mWebView.requestFocus();
                } else {
                    UnityPlayer.UnitySendMessage(unityReceiver, "OnWebViewClose", mWebView.getUrl());
                    mFrameLayout.setVisibility(View.GONE);
                    mWebView.loadUrl("about:blank");
                }
            }
        });
    }

    private static void InitUIWithPixels()
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable()
        {
            public void run()
            {
                if (mWebView != null)
                {
                    return;
                }
                //String packageName = UnityPlayer.currentActivity.getApplicationContext().getPackageName();
                Display display = UnityPlayer.currentActivity.getWindowManager().getDefaultDisplay();
                Point screenSize = new Point();
                display.getSize(screenSize);
                int screenWidth = screenSize.x;
                int screenHeight = screenSize.y;
                int standardWidth = 640;
                int standardHeight = 1136;
                float screenWidthScale = (float)screenWidth / standardWidth;
                float screenHeightScale = (float)screenHeight / standardHeight;
                //float screenScale = screenWidthScale < screenHeightScale ? screenWidthScale : screenHeightScale;
                float screenScale = screenHeightScale;

                //framelayout
                if (mFrameLayout == null)
                {
                    mFrameLayout = new FrameLayout(UnityPlayer.currentActivity);
                    UnityPlayer.currentActivity.addContentView(
                            mFrameLayout,
                            new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                }
                mFrameLayout.setVisibility(View.GONE);

                //Add a background ImageView to over the game activity, when the mWebView is GONE
                ImageView mFrameBackground = new ImageView(UnityPlayer.currentActivity);
                FrameLayout.LayoutParams mFrameBackgroundParams = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
                mFrameBackground.setBackgroundColor(Color.WHITE);
                mFrameBackground.setClickable(true);
                mFrameLayout.addView(mFrameBackground, mFrameBackgroundParams);

                //webview
                mWebView = new WebView(UnityPlayer.currentActivity);
                mWebView.setFocusable(true);
                mWebView.setFocusableInTouchMode(true);
                mWebView.setVerticalScrollBarEnabled(true);
                mWebView.setWebChromeClient(new WebChromeClient() {
                    /***
                     @Override public void onProgressChanged(WebView view, int progress) {
                     if (progress < 100) {
                     loadingView.setVisibility(View.VISIBLE);
                     loadingView.setRotation((float) 3600 / 100 * progress);
                     } else {
                     loadingView.setVisibility(View.GONE);
                     }
                     }
                     ***/

                    /***
                     * http://www.computerhope.com/issues/ch000178.htm
                     * only work for first time invoke
                     @Override public void onCloseWindow(WebView view){
                     Log.d("unity", "onCloseWindow: ------");
                     super.onCloseWindow(view);
                     SetVisibility(false);
                     }
                     ***/

                });
                mWebView.setWebViewClient(new WebViewClient() {
                    @SuppressWarnings("deprecation")
                    @Override
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        //super.onReceivedError(view, errorCode, description, failingUrl);
                        //Hide the mWebView to hide error message from js.
                        mWebView.setVisibility(View.GONE);
                        mWebView.loadUrl("about:blank");
                        pageLoading = false;
                        loadFailUrl = failingUrl;
                        SetFailPageVisibility(true);
                        //Log.d("unity", "onReceivedError: " + errorCode + "\n" + failingUrl);
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        //Log.d("unity", "shouldOverrideUrlLoading: " + url);
                        if (url.equals("app://close")) {
                            SetVisibility(false);
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }

                    @Override
                    public void onPageStarted(WebView view, String url, Bitmap favicon) {
                        if (url.equals("about:blank"))
                        {
                            //On android 4.2.1, blank page also invoke onPageStarted while android4.4 not.
                            return;
                        }
                        pageLoading = true;
                        //Android4.2.1's onPageStarted sometimes confused(invoke two times), so do this on LoadUrl and PostUrl.
                        //SetFailPageVisibility(false);
                        //mWebView.setVisibility(View.VISIBLE);
                        //Log.d("unity", "onPageStarted" + url);
                        ShowLoadingProgress();
                    }

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        pageLoading = false;
                        mWebView.requestLayout();
                        //Log.d("unity", "onPageFinished" + url);
                    }
                });
                WebSettings mWebSettings = mWebView.getSettings();
                mWebSettings.setJavaScriptEnabled(true);
                FrameLayout.LayoutParams mWebViewParams = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.NO_GRAVITY);

                //label background
                ImageView labelBg = new ImageView(UnityPlayer.currentActivity);
                labelBg.setBackgroundDrawable(GetDrawableFromAssets("webview_labelbg"));
                FrameLayout.LayoutParams labelBgParams = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                labelBgParams.topMargin = 0;

                int labelBgHeight =(int) (88 * screenScale);

                //Add in the order, the later add, the upper shown
                mWebViewParams.setMargins(0, labelBgHeight, 0, 0);
                mFrameLayout.addView(mWebView, mWebViewParams);

                labelBgParams.height = labelBgHeight;
                mFrameLayout.addView(labelBg, labelBgParams);

                //label
                ImageView label = new ImageView(UnityPlayer.currentActivity);
                //while using setBackgroundDrawable, setScaleType would not work, background image would always fill the layout
                //label.setBackgroundDrawable(GetDrawableFromAssets("webview_label"));
                label.setImageDrawable(GetDrawableFromAssets("webview_label"));
                int labelHeight = (int) (36 * screenScale);
                FrameLayout.LayoutParams labelParams = new FrameLayout.LayoutParams(labelBgParams.width, labelHeight, Gravity.CENTER_HORIZONTAL);
                labelParams.topMargin = (labelBgParams.height - labelParams.height) / 2;
                label.setScaleType(ImageView.ScaleType.FIT_CENTER);
                mFrameLayout.addView(label, labelParams);

                //close button
                final Button closeBtn = new Button(UnityPlayer.currentActivity);
                closeBtn.setBackgroundDrawable(GetDrawableFromAssets("webview_close"));
                closeBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        SetVisibility(false);
                    }
                });
                int closeBtnWidth = (int) (64 * screenScale);
                int closeBtnHeight = (int) (64 * screenScale);
                FrameLayout.LayoutParams closeBtnParams = new FrameLayout.LayoutParams(closeBtnWidth, closeBtnHeight, Gravity.RIGHT);
                closeBtnParams.topMargin = (labelBgParams.height - closeBtnParams.height) / 2;
                closeBtnParams.rightMargin = closeBtnParams.topMargin;
                mFrameLayout.addView(closeBtn, closeBtnParams);

                //loading
                loadingView = new ImageView(UnityPlayer.currentActivity);
                loadingView.setBackgroundDrawable(GetDrawableFromAssets("webview_loading"));
                int loadingViewWidth = (int) (48 * screenScale);
                int loadingViewHeight = (int) (48 * screenScale);
                FrameLayout.LayoutParams loadingViewParams = new FrameLayout.LayoutParams(loadingViewWidth, loadingViewHeight, Gravity.CENTER_HORIZONTAL);
                loadingViewParams.topMargin = (int) (215 * screenScale);
                mFrameLayout.addView(loadingView, loadingViewParams);

                /**    load fail page   **/
                loadFailTitle = new TextView(UnityPlayer.currentActivity);
                loadFailTitle.setText("Connection failed!");
                loadFailTitle.setTypeface(Typeface.DEFAULT_BOLD);
                loadFailTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                loadFailTitle.setTextColor(Color.BLACK);
                FrameLayout.LayoutParams loadFailTitleParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                loadFailTitleParams.topMargin = (int) (190 * screenScale);
                loadFailTitle.setVisibility(View.GONE);
                mFrameLayout.addView(loadFailTitle, loadFailTitleParams);

                loadFailMessage = new TextView(UnityPlayer.currentActivity);
                loadFailMessage.setText("No internet found now. Please check your connection and try again later.");
                loadFailMessage.setTypeface(Typeface.DEFAULT_BOLD);
                loadFailMessage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                loadFailMessage.setTextColor(Color.BLACK);
                FrameLayout.LayoutParams loadFailMessageParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                loadFailMessage.setGravity(Gravity.CENTER);
                loadFailMessageParams.topMargin = (int) (230 * screenScale);
                loadFailMessage.setVisibility(View.GONE);
                mFrameLayout.addView(loadFailMessage, loadFailMessageParams);

                loadFailRetryButton = new Button(UnityPlayer.currentActivity);
                loadFailRetryButton.setBackgroundDrawable(GetDrawableFromAssets("webview_retry"));
                loadFailRetryButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        LoadURL(loadFailUrl);
                        SetFailPageVisibility(false);
                    }
                });
                int loadFailRetryBtnWidth = (int) (400 * screenScale);
                int loadFailRetryBtnHeight = (int) (86 * screenScale);
                FrameLayout.LayoutParams loadFailRetryBtnParams = new FrameLayout.LayoutParams(loadFailRetryBtnWidth, loadFailRetryBtnHeight, Gravity.CENTER_HORIZONTAL);
                loadFailRetryBtnParams.topMargin = (int) (410 * screenScale);
                loadFailRetryButton.setVisibility(View.GONE);
                mFrameLayout.addView(loadFailRetryButton, loadFailRetryBtnParams);
            }
        });
    }

    private static void InitUIWithDps()
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable()
        {
            public void run()
            {
                if (mWebView != null)
                {
                    return;
                }
                String packageName = UnityPlayer.currentActivity.getApplicationContext().getPackageName();

                //framelayout
                if (mFrameLayout == null)
                {
                    mFrameLayout = new FrameLayout(UnityPlayer.currentActivity);
                    UnityPlayer.currentActivity.addContentView(
                            mFrameLayout,
                            new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                }
                mFrameLayout.setVisibility(View.GONE);

                //Add a background ImageView to over the game activity, when the mWebView is GONE
                ImageView mFrameBackground = new ImageView(UnityPlayer.currentActivity);
                FrameLayout.LayoutParams mFrameBackgroundParams = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
                mFrameBackground.setBackgroundColor(Color.WHITE);
                mFrameLayout.addView(mFrameBackground, mFrameBackgroundParams);

                //webview
                mWebView = new WebView(UnityPlayer.currentActivity);
                mWebView.setFocusable(true);
                mWebView.setFocusableInTouchMode(true);
                mWebView.setWebChromeClient(new WebChromeClient() {
                    /***
                     @Override
                     public void onProgressChanged(WebView view, int progress) {
                     if (progress < 100) {
                     loadingView.setVisibility(View.VISIBLE);
                     loadingView.setRotation((float) 3600 / 100 * progress);
                     } else {
                     loadingView.setVisibility(View.GONE);
                     }
                     }
                     ***/

                    /***
                     * http://www.computerhope.com/issues/ch000178.htm
                     * only work for first time invoke
                     @Override
                     public void onCloseWindow(WebView view){
                     Log.d("unity", "onCloseWindow: ------");
                     super.onCloseWindow(view);
                     SetVisibility(false);
                     }
                     ***/

                });
                mWebView.setWebViewClient(new WebViewClient() {
                    @SuppressWarnings("deprecation")
                    @Override
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        //super.onReceivedError(view, errorCode, description, failingUrl);
                        //Hide the mWebView to hide error message from js.
                        mWebView.setVisibility(View.GONE);
                        mWebView.loadUrl("about:blank");
                        pageLoading = false;
                        loadFailUrl = failingUrl;
                        SetFailPageVisibility(true);
                        //Log.d("unity", "onReceivedError: " + errorCode + "\n" + failingUrl);
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        //Log.d("unity", "shouldOverrideUrlLoading: " + url);
                        if (url.equals("app://close")) {
                            SetVisibility(false);
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }

                    @Override
                    public void onPageStarted(WebView view, String url, Bitmap favicon) {
                        if (url.equals("about:blank"))
                        {
                            //On android 4.2.1, blank page also invoke onPageStarted while android4.4 not.
                            return;
                        }
                        pageLoading = true;
                        //Android4.2.1's onPageStarted sometimes confused(invoke two times), so do this on LoadUrl and PostUrl.
                        //SetFailPageVisibility(false);
                        //mWebView.setVisibility(View.VISIBLE);
                        //Log.d("unity", "onPageStarted" + url);
                        ShowLoadingProgress();
                    }

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        pageLoading = false;
                        //Log.d("unity", "onPageFinished" + url);
                    }
                });
                WebSettings mWebSettings = mWebView.getSettings();
                //mWebSettings.setSupportZoom(false);
                //mWebSettings.setDisplayZoomControls(true);
                //mWebSettings.setDefaultZoom(WebSettings.ZoomDensity.CLOSE);
                //mWebSettings.setBuiltInZoomControls(true);
                mWebSettings.setJavaScriptEnabled(true);
                FrameLayout.LayoutParams mWebViewParams = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.NO_GRAVITY);
                //Add in the order, the later add, the upper shown
                mWebViewParams.setMargins(0, GetPixelsFromDps(70), 0, 0);
                mFrameLayout.addView(mWebView, mWebViewParams);

                //label background
                ImageView labelBg = new ImageView(UnityPlayer.currentActivity);
                labelBg.setBackgroundDrawable(GetDrawableFromAssets("webview_labelbg"));
                FrameLayout.LayoutParams labelBgParams = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                labelBgParams.topMargin = 0;
                labelBgParams.height = GetPixelsFromDps(70);
                mFrameLayout.addView(labelBg, labelBgParams);

                //label
                ImageView label = new ImageView(UnityPlayer.currentActivity);
                //while using setBackgroundDrawable, setScaleType would not work, background image would always fill the layout
                //label.setBackgroundDrawable(GetDrawableFromAssets("webview_label"));
                label.setImageDrawable(GetDrawableFromAssets("webview_label"));
                FrameLayout.LayoutParams labelParams = new FrameLayout.LayoutParams(labelBgParams.width, GetPixelsFromDps(30), Gravity.CENTER_HORIZONTAL);
                labelParams.topMargin = (labelBgParams.height - labelParams.height) / 2;
                label.setScaleType(ImageView.ScaleType.FIT_CENTER);
                mFrameLayout.addView(label, labelParams);

                //close button
                Button closeBtn = new Button(UnityPlayer.currentActivity);
                closeBtn.setBackgroundDrawable(GetDrawableFromAssets("webview_close"));
                closeBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        SetVisibility(false);
                    }
                });
                FrameLayout.LayoutParams closeBtnParams = new FrameLayout.LayoutParams(GetPixelsFromDps(40), GetPixelsFromDps(40), Gravity.RIGHT);
                closeBtnParams.topMargin = (labelBgParams.height - closeBtnParams.height) / 2;
                closeBtnParams.rightMargin = closeBtnParams.topMargin;
                mFrameLayout.addView(closeBtn, closeBtnParams);

                //loading
                loadingView = new ImageView(UnityPlayer.currentActivity);
                loadingView.setBackgroundDrawable(GetDrawableFromAssets("webview_loading"));
                FrameLayout.LayoutParams loadingViewParams = new FrameLayout.LayoutParams(GetPixelsFromDps(30), GetPixelsFromDps(30), Gravity.CENTER_HORIZONTAL);
                loadingViewParams.topMargin = GetPixelsFromDps(150);
                mFrameLayout.addView(loadingView, loadingViewParams);

                /**    load fail page   **/
                loadFailTitle = new TextView(UnityPlayer.currentActivity);
                loadFailTitle.setText("Connection failed!");
                loadFailTitle.setTypeface(Typeface.DEFAULT_BOLD);
                FrameLayout.LayoutParams loadFailTitleParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                loadFailTitleParams.topMargin = GetPixelsFromDps(100);
                loadFailTitle.setVisibility(View.GONE);
                mFrameLayout.addView(loadFailTitle, loadFailTitleParams);

                loadFailMessage = new TextView(UnityPlayer.currentActivity);
                loadFailMessage.setText("No internet found now. Please check your connection and try again later.");
                loadFailMessage.setTypeface(Typeface.DEFAULT_BOLD);
                FrameLayout.LayoutParams loadFailMessageParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
                loadFailMessage.setGravity(Gravity.CENTER);
                loadFailMessageParams.topMargin = GetPixelsFromDps(120);
                loadFailMessage.setVisibility(View.GONE);
                mFrameLayout.addView(loadFailMessage, loadFailMessageParams);

                loadFailRetryButton = new Button(UnityPlayer.currentActivity);
                loadFailRetryButton.setBackgroundDrawable(GetDrawableFromAssets("webview_retry"));
                loadFailRetryButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        LoadURL(loadFailUrl);
                        SetFailPageVisibility(false);
                    }
                });
                FrameLayout.LayoutParams loadFailRetryBtnParams = new FrameLayout.LayoutParams(GetPixelsFromDps(400 * 50 / 86), GetPixelsFromDps(50), Gravity.CENTER_HORIZONTAL);
                loadFailRetryBtnParams.topMargin = GetPixelsFromDps(170);
                loadFailRetryButton.setVisibility(View.GONE);
                mFrameLayout.addView(loadFailRetryButton, loadFailRetryBtnParams);
            }
        });
    }

    private static void SetFailPageVisibility(final boolean visibility)
    {
        UnityPlayer.currentActivity.runOnUiThread(new Runnable() {
            public void run() {
                if (mWebView == null) {
                    return;
                }
                if (visibility) {
                    loadFailTitle.setVisibility(View.VISIBLE);
                    loadFailMessage.setVisibility(View.VISIBLE);
                    loadFailRetryButton.setVisibility(View.VISIBLE);
                } else {
                    loadFailTitle.setVisibility(View.GONE);
                    loadFailMessage.setVisibility(View.GONE);
                    loadFailRetryButton.setVisibility(View.GONE);
                }
            }
        });
    }

    private static void ShowLoadingProgress()
    {
        new Thread() {
            public void run() {
                UnityPlayer.currentActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loadingView.setVisibility(View.VISIBLE);
                    }
                });
                while (pageLoading) {
                    try {
                        // 1 / 30 = 0.0333
                        Thread.sleep(33);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    UnityPlayer.currentActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            float lastRotation = loadingView.getRotation();
                            loadingView.setRotation(lastRotation + 10);
                        }
                    });
                }
                UnityPlayer.currentActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loadingView.setVisibility(View.GONE);
                    }
                });
            }
        }.start();
    }

    private static Drawable GetDrawableFromAssets(String imageName)
    {
        //http://stackoverflow.com/questions/4884882/is-it-possible-to-load-a-drawable-from-the-assets-folder
        String fileName = String.format("AppYeast/UnityWebView/%s.png", imageName);
        try
        {
            InputStream inputStream = UnityPlayer.currentActivity.getAssets().open(fileName);
            Drawable drawable = Drawable.createFromStream(inputStream, null);
            inputStream.close();
            return drawable;
        }
        catch(IOException e)
        {
            Log.e( "unity", "GetDrawableFromAssets File does not exist! " + fileName );
            return null;
        }
    }

    private static int GetPixelsFromDps(int dps)
    {
        final float scale = UnityPlayer.currentActivity.getResources().getDisplayMetrics().density;
        int pixels = (int) (dps * scale + 0.5f);
        return pixels;
    }
}
