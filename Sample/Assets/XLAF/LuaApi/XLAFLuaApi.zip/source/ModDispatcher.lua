ModDispatcher = {}

function ModDispatcher.Init () 
end

function ModDispatcher.Dispatch (eventName, data) 
end

function ModDispatcher.Dispatch (e) 
end

function ModDispatcher.AddListener (eventName, handler) 
end

function ModDispatcher.RemoveListener (eventName, handler) 
end

function ModDispatcher.HasListener (eventName, handler) 
end

function ModDispatcher:Equals (obj) 
end

function ModDispatcher:GetHashCode () 
end

function ModDispatcher:GetType () 
end

function ModDispatcher:ToString () 
end

