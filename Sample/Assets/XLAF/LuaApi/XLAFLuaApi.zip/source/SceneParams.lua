SceneParams = {}

function SceneParams:ToString () 
end

function SceneParams:Equals (obj) 
end

function SceneParams:GetHashCode () 
end

function SceneParams:GetType () 
end

