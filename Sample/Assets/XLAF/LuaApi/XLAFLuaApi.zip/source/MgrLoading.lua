MgrLoading = {}

useGUILayout = nil
runInEditMode = nil
enabled = nil
isActiveAndEnabled = nil
transform = nil
gameObject = nil
tag = nil
rigidbody = nil
rigidbody2D = nil
camera = nil
light = nil
animation = nil
constantForce = nil
renderer = nil
audio = nil
guiText = nil
networkView = nil
guiElement = nil
guiTexture = nil
collider = nil
collider2D = nil
hingeJoint = nil
particleEmitter = nil
particleSystem = nil
name = nil
hideFlags = nil
function MgrLoading.Init () 
end

function MgrLoading.ShowLoading (loadingName) 
end

function MgrLoading.Update () 
end

function MgrLoading:Invoke (methodName, time) 
end

function MgrLoading:InvokeRepeating (methodName, time, repeatRate) 
end

function MgrLoading:CancelInvoke () 
end

function MgrLoading:CancelInvoke (methodName) 
end

function MgrLoading:IsInvoking (methodName) 
end

function MgrLoading:IsInvoking () 
end

function MgrLoading:StartCoroutine (routine) 
end

function MgrLoading:StartCoroutine_Auto (routine) 
end

function MgrLoading:StartCoroutine (methodName, value) 
end

function MgrLoading:StartCoroutine (methodName) 
end

function MgrLoading:StopCoroutine (methodName) 
end

function MgrLoading:StopCoroutine (routine) 
end

function MgrLoading:StopCoroutine (routine) 
end

function MgrLoading:StopAllCoroutines () 
end

function MgrLoading:GetComponent (type) 
end

function MgrLoading:GetComponent () 
end

function MgrLoading:GetComponent (type) 
end

function MgrLoading:GetComponentInChildren (t, includeInactive) 
end

function MgrLoading:GetComponentInChildren (t) 
end

function MgrLoading:GetComponentInChildren () 
end

function MgrLoading:GetComponentInChildren (includeInactive) 
end

function MgrLoading:GetComponentsInChildren (t) 
end

function MgrLoading:GetComponentsInChildren (t, includeInactive) 
end

function MgrLoading:GetComponentsInChildren (includeInactive) 
end

function MgrLoading:GetComponentsInChildren (includeInactive, result) 
end

function MgrLoading:GetComponentsInChildren () 
end

function MgrLoading:GetComponentsInChildren (results) 
end

function MgrLoading:GetComponentInParent (t) 
end

function MgrLoading:GetComponentInParent () 
end

function MgrLoading:GetComponentsInParent (t) 
end

function MgrLoading:GetComponentsInParent (t, includeInactive) 
end

function MgrLoading:GetComponentsInParent (includeInactive) 
end

function MgrLoading:GetComponentsInParent (includeInactive, results) 
end

function MgrLoading:GetComponentsInParent () 
end

function MgrLoading:GetComponents (type) 
end

function MgrLoading:GetComponents (type, results) 
end

function MgrLoading:GetComponents (results) 
end

function MgrLoading:GetComponents () 
end

function MgrLoading:CompareTag (tag) 
end

function MgrLoading:SendMessageUpwards (methodName, value, options) 
end

function MgrLoading:SendMessageUpwards (methodName, value) 
end

function MgrLoading:SendMessageUpwards (methodName) 
end

function MgrLoading:SendMessageUpwards (methodName, options) 
end

function MgrLoading:SendMessage (methodName, value, options) 
end

function MgrLoading:SendMessage (methodName, value) 
end

function MgrLoading:SendMessage (methodName) 
end

function MgrLoading:SendMessage (methodName, options) 
end

function MgrLoading:BroadcastMessage (methodName, parameter, options) 
end

function MgrLoading:BroadcastMessage (methodName, parameter) 
end

function MgrLoading:BroadcastMessage (methodName) 
end

function MgrLoading:BroadcastMessage (methodName, options) 
end

function MgrLoading:ToString () 
end

function MgrLoading:GetInstanceID () 
end

function MgrLoading:GetHashCode () 
end

function MgrLoading:Equals (other) 
end

function MgrLoading:GetType () 
end

