Storyboard = {}

sceneName = nil
sceneObject = nil
preventDoubleClickTime = nil
useGUILayout = nil
runInEditMode = nil
enabled = nil
isActiveAndEnabled = nil
transform = nil
gameObject = nil
tag = nil
rigidbody = nil
rigidbody2D = nil
camera = nil
light = nil
animation = nil
constantForce = nil
renderer = nil
audio = nil
guiText = nil
networkView = nil
guiElement = nil
guiTexture = nil
collider = nil
collider2D = nil
hingeJoint = nil
particleEmitter = nil
particleSystem = nil
name = nil
hideFlags = nil
function Storyboard:CreateScene (obj) 
end

function Storyboard:WillEnterScene (obj) 
end

function Storyboard:EnterScene (obj) 
end

function Storyboard:WillExitScene () 
end

function Storyboard:ExitScene () 
end

function Storyboard:DestroyScene () 
end

function Storyboard:OverlayBegan (overlaySceneceneName) 
end

function Storyboard:OverlayEnded (overlaySceneceneName) 
end

function Storyboard:UpdateLanguage () 
end

function Storyboard:AndroidGoBack () 
end

function Storyboard:OnUIEvent (e) 
end

function Storyboard:OnXLAFEvent (e) 
end

function Storyboard:BindAllButtonsClickEvent () 
end

function Storyboard:Invoke (methodName, time) 
end

function Storyboard:InvokeRepeating (methodName, time, repeatRate) 
end

function Storyboard:CancelInvoke () 
end

function Storyboard:CancelInvoke (methodName) 
end

function Storyboard:IsInvoking (methodName) 
end

function Storyboard:IsInvoking () 
end

function Storyboard:StartCoroutine (routine) 
end

function Storyboard:StartCoroutine_Auto (routine) 
end

function Storyboard:StartCoroutine (methodName, value) 
end

function Storyboard:StartCoroutine (methodName) 
end

function Storyboard:StopCoroutine (methodName) 
end

function Storyboard:StopCoroutine (routine) 
end

function Storyboard:StopCoroutine (routine) 
end

function Storyboard:StopAllCoroutines () 
end

function Storyboard:GetComponent (type) 
end

function Storyboard:GetComponent () 
end

function Storyboard:GetComponent (type) 
end

function Storyboard:GetComponentInChildren (t, includeInactive) 
end

function Storyboard:GetComponentInChildren (t) 
end

function Storyboard:GetComponentInChildren () 
end

function Storyboard:GetComponentInChildren (includeInactive) 
end

function Storyboard:GetComponentsInChildren (t) 
end

function Storyboard:GetComponentsInChildren (t, includeInactive) 
end

function Storyboard:GetComponentsInChildren (includeInactive) 
end

function Storyboard:GetComponentsInChildren (includeInactive, result) 
end

function Storyboard:GetComponentsInChildren () 
end

function Storyboard:GetComponentsInChildren (results) 
end

function Storyboard:GetComponentInParent (t) 
end

function Storyboard:GetComponentInParent () 
end

function Storyboard:GetComponentsInParent (t) 
end

function Storyboard:GetComponentsInParent (t, includeInactive) 
end

function Storyboard:GetComponentsInParent (includeInactive) 
end

function Storyboard:GetComponentsInParent (includeInactive, results) 
end

function Storyboard:GetComponentsInParent () 
end

function Storyboard:GetComponents (type) 
end

function Storyboard:GetComponents (type, results) 
end

function Storyboard:GetComponents (results) 
end

function Storyboard:GetComponents () 
end

function Storyboard:CompareTag (tag) 
end

function Storyboard:SendMessageUpwards (methodName, value, options) 
end

function Storyboard:SendMessageUpwards (methodName, value) 
end

function Storyboard:SendMessageUpwards (methodName) 
end

function Storyboard:SendMessageUpwards (methodName, options) 
end

function Storyboard:SendMessage (methodName, value, options) 
end

function Storyboard:SendMessage (methodName, value) 
end

function Storyboard:SendMessage (methodName) 
end

function Storyboard:SendMessage (methodName, options) 
end

function Storyboard:BroadcastMessage (methodName, parameter, options) 
end

function Storyboard:BroadcastMessage (methodName, parameter) 
end

function Storyboard:BroadcastMessage (methodName) 
end

function Storyboard:BroadcastMessage (methodName, options) 
end

function Storyboard:ToString () 
end

function Storyboard:GetInstanceID () 
end

function Storyboard:GetHashCode () 
end

function Storyboard:Equals (other) 
end

function Storyboard:GetType () 
end

