MgrMultiLanguage = {}

function MgrMultiLanguage.Init () 
end

function MgrMultiLanguage.GetCurrentLanguage () 
end

function MgrMultiLanguage.SwitchLanguage (lang) 
end

function MgrMultiLanguage.GetString (stringKeyName) 
end

function MgrMultiLanguage.GetString (stringKeyName, ...) 
end

function MgrMultiLanguage:Equals (obj) 
end

function MgrMultiLanguage:GetHashCode () 
end

function MgrMultiLanguage:GetType () 
end

function MgrMultiLanguage:ToString () 
end

