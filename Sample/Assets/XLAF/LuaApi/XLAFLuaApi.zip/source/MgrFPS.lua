MgrFPS = {}

useGUILayout = nil
runInEditMode = nil
enabled = nil
isActiveAndEnabled = nil
transform = nil
gameObject = nil
tag = nil
rigidbody = nil
rigidbody2D = nil
camera = nil
light = nil
animation = nil
constantForce = nil
renderer = nil
audio = nil
guiText = nil
networkView = nil
guiElement = nil
guiTexture = nil
collider = nil
collider2D = nil
hingeJoint = nil
particleEmitter = nil
particleSystem = nil
name = nil
hideFlags = nil
function MgrFPS.Init () 
end

function MgrFPS.ShowFPS () 
end

function MgrFPS.HideFPS () 
end

function MgrFPS:Invoke (methodName, time) 
end

function MgrFPS:InvokeRepeating (methodName, time, repeatRate) 
end

function MgrFPS:CancelInvoke () 
end

function MgrFPS:CancelInvoke (methodName) 
end

function MgrFPS:IsInvoking (methodName) 
end

function MgrFPS:IsInvoking () 
end

function MgrFPS:StartCoroutine (routine) 
end

function MgrFPS:StartCoroutine_Auto (routine) 
end

function MgrFPS:StartCoroutine (methodName, value) 
end

function MgrFPS:StartCoroutine (methodName) 
end

function MgrFPS:StopCoroutine (methodName) 
end

function MgrFPS:StopCoroutine (routine) 
end

function MgrFPS:StopCoroutine (routine) 
end

function MgrFPS:StopAllCoroutines () 
end

function MgrFPS:GetComponent (type) 
end

function MgrFPS:GetComponent () 
end

function MgrFPS:GetComponent (type) 
end

function MgrFPS:GetComponentInChildren (t, includeInactive) 
end

function MgrFPS:GetComponentInChildren (t) 
end

function MgrFPS:GetComponentInChildren () 
end

function MgrFPS:GetComponentInChildren (includeInactive) 
end

function MgrFPS:GetComponentsInChildren (t) 
end

function MgrFPS:GetComponentsInChildren (t, includeInactive) 
end

function MgrFPS:GetComponentsInChildren (includeInactive) 
end

function MgrFPS:GetComponentsInChildren (includeInactive, result) 
end

function MgrFPS:GetComponentsInChildren () 
end

function MgrFPS:GetComponentsInChildren (results) 
end

function MgrFPS:GetComponentInParent (t) 
end

function MgrFPS:GetComponentInParent () 
end

function MgrFPS:GetComponentsInParent (t) 
end

function MgrFPS:GetComponentsInParent (t, includeInactive) 
end

function MgrFPS:GetComponentsInParent (includeInactive) 
end

function MgrFPS:GetComponentsInParent (includeInactive, results) 
end

function MgrFPS:GetComponentsInParent () 
end

function MgrFPS:GetComponents (type) 
end

function MgrFPS:GetComponents (type, results) 
end

function MgrFPS:GetComponents (results) 
end

function MgrFPS:GetComponents () 
end

function MgrFPS:CompareTag (tag) 
end

function MgrFPS:SendMessageUpwards (methodName, value, options) 
end

function MgrFPS:SendMessageUpwards (methodName, value) 
end

function MgrFPS:SendMessageUpwards (methodName) 
end

function MgrFPS:SendMessageUpwards (methodName, options) 
end

function MgrFPS:SendMessage (methodName, value, options) 
end

function MgrFPS:SendMessage (methodName, value) 
end

function MgrFPS:SendMessage (methodName) 
end

function MgrFPS:SendMessage (methodName, options) 
end

function MgrFPS:BroadcastMessage (methodName, parameter, options) 
end

function MgrFPS:BroadcastMessage (methodName, parameter) 
end

function MgrFPS:BroadcastMessage (methodName) 
end

function MgrFPS:BroadcastMessage (methodName, options) 
end

function MgrFPS:ToString () 
end

function MgrFPS:GetInstanceID () 
end

function MgrFPS:GetHashCode () 
end

function MgrFPS:Equals (other) 
end

function MgrFPS:GetType () 
end

