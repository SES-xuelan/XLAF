XLAFMain = {}

XLAFGameObject = nil
function XLAFMain.Init () 
end

function XLAFMain:Equals (obj) 
end

function XLAFMain:GetHashCode () 
end

function XLAFMain:GetType () 
end

function XLAFMain:ToString () 
end

