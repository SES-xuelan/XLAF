ModEncryption = {}

aes_key = nil
aes_IV = nil
zzz_key = nil
function ModEncryption.Init () 
end

function ModEncryption.MD5Encrypt16 (str) 
end

function ModEncryption.MD5Encrypt32 (str) 
end

function ModEncryption.EncodeBase64 (str) 
end

function ModEncryption.DecodeBase64 (str) 
end

function ModEncryption.EncodeAES (str) 
end

function ModEncryption.DecodeAES (base64Str) 
end

function ModEncryption.DecodeZZZ (bytes) 
end

function ModEncryption:Equals (obj) 
end

function ModEncryption:GetHashCode () 
end

function ModEncryption:GetType () 
end

function ModEncryption:ToString () 
end

