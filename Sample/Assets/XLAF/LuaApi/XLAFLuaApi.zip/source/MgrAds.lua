MgrAds = {}

function MgrAds.Init () 
end

function MgrAds.ShowScreenAds () 
end

function MgrAds.ShowRewardVideo () 
end

function MgrAds.ShowBanner () 
end

function MgrAds.ShowBannerABS () 
end

function MgrAds.HideBanner () 
end

function MgrAds.ShowNativeBanner () 
end

function MgrAds.ShowNativeBannerABS () 
end

function MgrAds.HideNativeBanner () 
end

function MgrAds:Equals (obj) 
end

function MgrAds:GetHashCode () 
end

function MgrAds:GetType () 
end

function MgrAds:ToString () 
end

