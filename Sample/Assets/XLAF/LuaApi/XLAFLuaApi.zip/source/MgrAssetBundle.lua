MgrAssetBundle = {}

assetbundleConfigFile = nil
function MgrAssetBundle.Init () 
end

function MgrAssetBundle.ReloadConfig () 
end

function MgrAssetBundle.GetAssetBundlePath (sceneName) 
end

function MgrAssetBundle.HasAssetBundle (sceneName) 
end

function MgrAssetBundle:Equals (obj) 
end

function MgrAssetBundle:GetHashCode () 
end

function MgrAssetBundle:GetType () 
end

function MgrAssetBundle:ToString () 
end

