Log = {}

isWarnOn = nil
isInfoOn = nil
isDebugOn = nil
isErrorOn = nil
isWriteToFile = nil
deep = nil
function Log.Init () 
end

function Log.SetDebugLevel (level) 
end

function Log.SetWriteToFile (isOn) 
end

function Log.SetInnerLogShown (isShow) 
end

function Log.Debug (...) 
end

function Log.Error (...) 
end

function Log.Warning (...) 
end

function Log.Info (...) 
end

function Log:Equals (obj) 
end

function Log:GetHashCode () 
end

function Log:GetType () 
end

function Log:ToString () 
end

