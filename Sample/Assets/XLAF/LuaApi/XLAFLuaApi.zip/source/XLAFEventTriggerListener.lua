XLAFEventTriggerListener = {}

useGUILayout = nil
runInEditMode = nil
enabled = nil
isActiveAndEnabled = nil
transform = nil
gameObject = nil
tag = nil
rigidbody = nil
rigidbody2D = nil
camera = nil
light = nil
animation = nil
constantForce = nil
renderer = nil
audio = nil
guiText = nil
networkView = nil
guiElement = nil
guiTexture = nil
collider = nil
collider2D = nil
hingeJoint = nil
particleEmitter = nil
particleSystem = nil
name = nil
hideFlags = nil
function XLAFEventTriggerListener.Get (go) 
end

function XLAFEventTriggerListener:OnPointerClick (eventData) 
end

function XLAFEventTriggerListener:OnPointerDown (eventData) 
end

function XLAFEventTriggerListener:OnPointerEnter (eventData) 
end

function XLAFEventTriggerListener:OnPointerExit (eventData) 
end

function XLAFEventTriggerListener:OnPointerUp (eventData) 
end

function XLAFEventTriggerListener:OnBeginDrag (eventData) 
end

function XLAFEventTriggerListener:OnDrag (eventData) 
end

function XLAFEventTriggerListener:OnEndDrag (eventData) 
end

function XLAFEventTriggerListener:Invoke (methodName, time) 
end

function XLAFEventTriggerListener:InvokeRepeating (methodName, time, repeatRate) 
end

function XLAFEventTriggerListener:CancelInvoke () 
end

function XLAFEventTriggerListener:CancelInvoke (methodName) 
end

function XLAFEventTriggerListener:IsInvoking (methodName) 
end

function XLAFEventTriggerListener:IsInvoking () 
end

function XLAFEventTriggerListener:StartCoroutine (routine) 
end

function XLAFEventTriggerListener:StartCoroutine_Auto (routine) 
end

function XLAFEventTriggerListener:StartCoroutine (methodName, value) 
end

function XLAFEventTriggerListener:StartCoroutine (methodName) 
end

function XLAFEventTriggerListener:StopCoroutine (methodName) 
end

function XLAFEventTriggerListener:StopCoroutine (routine) 
end

function XLAFEventTriggerListener:StopCoroutine (routine) 
end

function XLAFEventTriggerListener:StopAllCoroutines () 
end

function XLAFEventTriggerListener:GetComponent (type) 
end

function XLAFEventTriggerListener:GetComponent () 
end

function XLAFEventTriggerListener:GetComponent (type) 
end

function XLAFEventTriggerListener:GetComponentInChildren (t, includeInactive) 
end

function XLAFEventTriggerListener:GetComponentInChildren (t) 
end

function XLAFEventTriggerListener:GetComponentInChildren () 
end

function XLAFEventTriggerListener:GetComponentInChildren (includeInactive) 
end

function XLAFEventTriggerListener:GetComponentsInChildren (t) 
end

function XLAFEventTriggerListener:GetComponentsInChildren (t, includeInactive) 
end

function XLAFEventTriggerListener:GetComponentsInChildren (includeInactive) 
end

function XLAFEventTriggerListener:GetComponentsInChildren (includeInactive, result) 
end

function XLAFEventTriggerListener:GetComponentsInChildren () 
end

function XLAFEventTriggerListener:GetComponentsInChildren (results) 
end

function XLAFEventTriggerListener:GetComponentInParent (t) 
end

function XLAFEventTriggerListener:GetComponentInParent () 
end

function XLAFEventTriggerListener:GetComponentsInParent (t) 
end

function XLAFEventTriggerListener:GetComponentsInParent (t, includeInactive) 
end

function XLAFEventTriggerListener:GetComponentsInParent (includeInactive) 
end

function XLAFEventTriggerListener:GetComponentsInParent (includeInactive, results) 
end

function XLAFEventTriggerListener:GetComponentsInParent () 
end

function XLAFEventTriggerListener:GetComponents (type) 
end

function XLAFEventTriggerListener:GetComponents (type, results) 
end

function XLAFEventTriggerListener:GetComponents (results) 
end

function XLAFEventTriggerListener:GetComponents () 
end

function XLAFEventTriggerListener:CompareTag (tag) 
end

function XLAFEventTriggerListener:SendMessageUpwards (methodName, value, options) 
end

function XLAFEventTriggerListener:SendMessageUpwards (methodName, value) 
end

function XLAFEventTriggerListener:SendMessageUpwards (methodName) 
end

function XLAFEventTriggerListener:SendMessageUpwards (methodName, options) 
end

function XLAFEventTriggerListener:SendMessage (methodName, value, options) 
end

function XLAFEventTriggerListener:SendMessage (methodName, value) 
end

function XLAFEventTriggerListener:SendMessage (methodName) 
end

function XLAFEventTriggerListener:SendMessage (methodName, options) 
end

function XLAFEventTriggerListener:BroadcastMessage (methodName, parameter, options) 
end

function XLAFEventTriggerListener:BroadcastMessage (methodName, parameter) 
end

function XLAFEventTriggerListener:BroadcastMessage (methodName) 
end

function XLAFEventTriggerListener:BroadcastMessage (methodName, options) 
end

function XLAFEventTriggerListener:ToString () 
end

function XLAFEventTriggerListener:GetInstanceID () 
end

function XLAFEventTriggerListener:GetHashCode () 
end

function XLAFEventTriggerListener:Equals (other) 
end

function XLAFEventTriggerListener:GetType () 
end

