MgrBackdoor = {}

useGUILayout = nil
runInEditMode = nil
enabled = nil
isActiveAndEnabled = nil
transform = nil
gameObject = nil
tag = nil
rigidbody = nil
rigidbody2D = nil
camera = nil
light = nil
animation = nil
constantForce = nil
renderer = nil
audio = nil
guiText = nil
networkView = nil
guiElement = nil
guiTexture = nil
collider = nil
collider2D = nil
hingeJoint = nil
particleEmitter = nil
particleSystem = nil
name = nil
hideFlags = nil
function MgrBackdoor.Init () 
end

function MgrBackdoor.SetBackdoor (transform, callback) 
end

function MgrBackdoor.SetBackdoor (gameObject, callback) 
end

function MgrBackdoor:Invoke (methodName, time) 
end

function MgrBackdoor:InvokeRepeating (methodName, time, repeatRate) 
end

function MgrBackdoor:CancelInvoke () 
end

function MgrBackdoor:CancelInvoke (methodName) 
end

function MgrBackdoor:IsInvoking (methodName) 
end

function MgrBackdoor:IsInvoking () 
end

function MgrBackdoor:StartCoroutine (routine) 
end

function MgrBackdoor:StartCoroutine_Auto (routine) 
end

function MgrBackdoor:StartCoroutine (methodName, value) 
end

function MgrBackdoor:StartCoroutine (methodName) 
end

function MgrBackdoor:StopCoroutine (methodName) 
end

function MgrBackdoor:StopCoroutine (routine) 
end

function MgrBackdoor:StopCoroutine (routine) 
end

function MgrBackdoor:StopAllCoroutines () 
end

function MgrBackdoor:GetComponent (type) 
end

function MgrBackdoor:GetComponent () 
end

function MgrBackdoor:GetComponent (type) 
end

function MgrBackdoor:GetComponentInChildren (t, includeInactive) 
end

function MgrBackdoor:GetComponentInChildren (t) 
end

function MgrBackdoor:GetComponentInChildren () 
end

function MgrBackdoor:GetComponentInChildren (includeInactive) 
end

function MgrBackdoor:GetComponentsInChildren (t) 
end

function MgrBackdoor:GetComponentsInChildren (t, includeInactive) 
end

function MgrBackdoor:GetComponentsInChildren (includeInactive) 
end

function MgrBackdoor:GetComponentsInChildren (includeInactive, result) 
end

function MgrBackdoor:GetComponentsInChildren () 
end

function MgrBackdoor:GetComponentsInChildren (results) 
end

function MgrBackdoor:GetComponentInParent (t) 
end

function MgrBackdoor:GetComponentInParent () 
end

function MgrBackdoor:GetComponentsInParent (t) 
end

function MgrBackdoor:GetComponentsInParent (t, includeInactive) 
end

function MgrBackdoor:GetComponentsInParent (includeInactive) 
end

function MgrBackdoor:GetComponentsInParent (includeInactive, results) 
end

function MgrBackdoor:GetComponentsInParent () 
end

function MgrBackdoor:GetComponents (type) 
end

function MgrBackdoor:GetComponents (type, results) 
end

function MgrBackdoor:GetComponents (results) 
end

function MgrBackdoor:GetComponents () 
end

function MgrBackdoor:CompareTag (tag) 
end

function MgrBackdoor:SendMessageUpwards (methodName, value, options) 
end

function MgrBackdoor:SendMessageUpwards (methodName, value) 
end

function MgrBackdoor:SendMessageUpwards (methodName) 
end

function MgrBackdoor:SendMessageUpwards (methodName, options) 
end

function MgrBackdoor:SendMessage (methodName, value, options) 
end

function MgrBackdoor:SendMessage (methodName, value) 
end

function MgrBackdoor:SendMessage (methodName) 
end

function MgrBackdoor:SendMessage (methodName, options) 
end

function MgrBackdoor:BroadcastMessage (methodName, parameter, options) 
end

function MgrBackdoor:BroadcastMessage (methodName, parameter) 
end

function MgrBackdoor:BroadcastMessage (methodName) 
end

function MgrBackdoor:BroadcastMessage (methodName, options) 
end

function MgrBackdoor:ToString () 
end

function MgrBackdoor:GetInstanceID () 
end

function MgrBackdoor:GetHashCode () 
end

function MgrBackdoor:Equals (other) 
end

function MgrBackdoor:GetType () 
end

