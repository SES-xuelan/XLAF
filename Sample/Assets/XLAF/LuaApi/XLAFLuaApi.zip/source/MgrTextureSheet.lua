MgrTextureSheet = {}

instance = nil
useGUILayout = nil
runInEditMode = nil
enabled = nil
isActiveAndEnabled = nil
transform = nil
gameObject = nil
tag = nil
rigidbody = nil
rigidbody2D = nil
camera = nil
light = nil
animation = nil
constantForce = nil
renderer = nil
audio = nil
guiText = nil
networkView = nil
guiElement = nil
guiTexture = nil
collider = nil
collider2D = nil
hingeJoint = nil
particleEmitter = nil
particleSystem = nil
name = nil
hideFlags = nil
function MgrTextureSheet.Init () 
end

function MgrTextureSheet:LoadSprite (sheetPath, spriteName) 
end

function MgrTextureSheet:DeleteSheetCache (sheetPath) 
end

function MgrTextureSheet:Invoke (methodName, time) 
end

function MgrTextureSheet:InvokeRepeating (methodName, time, repeatRate) 
end

function MgrTextureSheet:CancelInvoke () 
end

function MgrTextureSheet:CancelInvoke (methodName) 
end

function MgrTextureSheet:IsInvoking (methodName) 
end

function MgrTextureSheet:IsInvoking () 
end

function MgrTextureSheet:StartCoroutine (routine) 
end

function MgrTextureSheet:StartCoroutine_Auto (routine) 
end

function MgrTextureSheet:StartCoroutine (methodName, value) 
end

function MgrTextureSheet:StartCoroutine (methodName) 
end

function MgrTextureSheet:StopCoroutine (methodName) 
end

function MgrTextureSheet:StopCoroutine (routine) 
end

function MgrTextureSheet:StopCoroutine (routine) 
end

function MgrTextureSheet:StopAllCoroutines () 
end

function MgrTextureSheet:GetComponent (type) 
end

function MgrTextureSheet:GetComponent () 
end

function MgrTextureSheet:GetComponent (type) 
end

function MgrTextureSheet:GetComponentInChildren (t, includeInactive) 
end

function MgrTextureSheet:GetComponentInChildren (t) 
end

function MgrTextureSheet:GetComponentInChildren () 
end

function MgrTextureSheet:GetComponentInChildren (includeInactive) 
end

function MgrTextureSheet:GetComponentsInChildren (t) 
end

function MgrTextureSheet:GetComponentsInChildren (t, includeInactive) 
end

function MgrTextureSheet:GetComponentsInChildren (includeInactive) 
end

function MgrTextureSheet:GetComponentsInChildren (includeInactive, result) 
end

function MgrTextureSheet:GetComponentsInChildren () 
end

function MgrTextureSheet:GetComponentsInChildren (results) 
end

function MgrTextureSheet:GetComponentInParent (t) 
end

function MgrTextureSheet:GetComponentInParent () 
end

function MgrTextureSheet:GetComponentsInParent (t) 
end

function MgrTextureSheet:GetComponentsInParent (t, includeInactive) 
end

function MgrTextureSheet:GetComponentsInParent (includeInactive) 
end

function MgrTextureSheet:GetComponentsInParent (includeInactive, results) 
end

function MgrTextureSheet:GetComponentsInParent () 
end

function MgrTextureSheet:GetComponents (type) 
end

function MgrTextureSheet:GetComponents (type, results) 
end

function MgrTextureSheet:GetComponents (results) 
end

function MgrTextureSheet:GetComponents () 
end

function MgrTextureSheet:CompareTag (tag) 
end

function MgrTextureSheet:SendMessageUpwards (methodName, value, options) 
end

function MgrTextureSheet:SendMessageUpwards (methodName, value) 
end

function MgrTextureSheet:SendMessageUpwards (methodName) 
end

function MgrTextureSheet:SendMessageUpwards (methodName, options) 
end

function MgrTextureSheet:SendMessage (methodName, value, options) 
end

function MgrTextureSheet:SendMessage (methodName, value) 
end

function MgrTextureSheet:SendMessage (methodName) 
end

function MgrTextureSheet:SendMessage (methodName, options) 
end

function MgrTextureSheet:BroadcastMessage (methodName, parameter, options) 
end

function MgrTextureSheet:BroadcastMessage (methodName, parameter) 
end

function MgrTextureSheet:BroadcastMessage (methodName) 
end

function MgrTextureSheet:BroadcastMessage (methodName, options) 
end

function MgrTextureSheet:ToString () 
end

function MgrTextureSheet:GetInstanceID () 
end

function MgrTextureSheet:GetHashCode () 
end

function MgrTextureSheet:Equals (other) 
end

function MgrTextureSheet:GetType () 
end

