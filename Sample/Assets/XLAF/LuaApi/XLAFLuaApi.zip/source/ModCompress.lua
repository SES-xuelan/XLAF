ModCompress = {}

function ModCompress.Compress (fileOrDirectoryArray, outputPathName, password, zipCallback) 
end

function ModCompress.Decompress (filePathName, outputPath, password, unzipCallback) 
end

function ModCompress.Decompress (fileBytes, outputPath, password, unzipCallback) 
end

function ModCompress.Decompress (inputStream, outputPath, password, unzipCallback) 
end

function ModCompress:Equals (obj) 
end

function ModCompress:GetHashCode () 
end

function ModCompress:GetType () 
end

function ModCompress:ToString () 
end

