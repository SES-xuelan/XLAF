MgrLevel = {}

function MgrLevel.Init () 
end

function MgrLevel:Equals (obj) 
end

function MgrLevel:GetHashCode () 
end

function MgrLevel:GetType () 
end

function MgrLevel:ToString () 
end

