XLAF_Event = {}

name = nil
data = nil
action = nil
function XLAF_Event:ToString () 
end

function XLAF_Event:Equals (obj) 
end

function XLAF_Event:GetHashCode () 
end

function XLAF_Event:GetType () 
end

