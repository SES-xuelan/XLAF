XLAF_UIEvent = {}

target = nil
phase = nil
eventData = nil
function XLAF_UIEvent:ToString () 
end

function XLAF_UIEvent:Equals (obj) 
end

function XLAF_UIEvent:GetHashCode () 
end

function XLAF_UIEvent:GetType () 
end

