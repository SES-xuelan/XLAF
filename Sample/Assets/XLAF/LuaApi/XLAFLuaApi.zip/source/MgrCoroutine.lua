MgrCoroutine = {}

function MgrCoroutine.Init () 
end

function MgrCoroutine.DoCoroutine (routine) 
end

function MgrCoroutine:Equals (obj) 
end

function MgrCoroutine:GetHashCode () 
end

function MgrCoroutine:GetType () 
end

function MgrCoroutine:ToString () 
end

