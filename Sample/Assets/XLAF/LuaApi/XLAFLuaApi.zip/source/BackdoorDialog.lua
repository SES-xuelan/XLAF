BackdoorDialog = {}

sceneName = nil
sceneObject = nil
preventDoubleClickTime = nil
useGUILayout = nil
runInEditMode = nil
enabled = nil
isActiveAndEnabled = nil
transform = nil
gameObject = nil
tag = nil
rigidbody = nil
rigidbody2D = nil
camera = nil
light = nil
animation = nil
constantForce = nil
renderer = nil
audio = nil
guiText = nil
networkView = nil
guiElement = nil
guiTexture = nil
collider = nil
collider2D = nil
hingeJoint = nil
particleEmitter = nil
particleSystem = nil
name = nil
hideFlags = nil
function BackdoorDialog:OnUIEvent (e) 
end

function BackdoorDialog:CreateScene (obj) 
end

function BackdoorDialog:WillEnterScene (obj) 
end

function BackdoorDialog:EnterScene (obj) 
end

function BackdoorDialog:WillExitScene () 
end

function BackdoorDialog:ExitScene () 
end

function BackdoorDialog:DestroyScene () 
end

function BackdoorDialog:UpdateLanguage () 
end

function BackdoorDialog:AndroidGoBack () 
end

function BackdoorDialog:OverlayBegan (overlaySceneceneName) 
end

function BackdoorDialog:OverlayEnded (overlaySceneceneName) 
end

function BackdoorDialog:OnXLAFEvent (e) 
end

function BackdoorDialog:BindAllButtonsClickEvent () 
end

function BackdoorDialog:Invoke (methodName, time) 
end

function BackdoorDialog:InvokeRepeating (methodName, time, repeatRate) 
end

function BackdoorDialog:CancelInvoke () 
end

function BackdoorDialog:CancelInvoke (methodName) 
end

function BackdoorDialog:IsInvoking (methodName) 
end

function BackdoorDialog:IsInvoking () 
end

function BackdoorDialog:StartCoroutine (routine) 
end

function BackdoorDialog:StartCoroutine_Auto (routine) 
end

function BackdoorDialog:StartCoroutine (methodName, value) 
end

function BackdoorDialog:StartCoroutine (methodName) 
end

function BackdoorDialog:StopCoroutine (methodName) 
end

function BackdoorDialog:StopCoroutine (routine) 
end

function BackdoorDialog:StopCoroutine (routine) 
end

function BackdoorDialog:StopAllCoroutines () 
end

function BackdoorDialog:GetComponent (type) 
end

function BackdoorDialog:GetComponent () 
end

function BackdoorDialog:GetComponent (type) 
end

function BackdoorDialog:GetComponentInChildren (t, includeInactive) 
end

function BackdoorDialog:GetComponentInChildren (t) 
end

function BackdoorDialog:GetComponentInChildren () 
end

function BackdoorDialog:GetComponentInChildren (includeInactive) 
end

function BackdoorDialog:GetComponentsInChildren (t) 
end

function BackdoorDialog:GetComponentsInChildren (t, includeInactive) 
end

function BackdoorDialog:GetComponentsInChildren (includeInactive) 
end

function BackdoorDialog:GetComponentsInChildren (includeInactive, result) 
end

function BackdoorDialog:GetComponentsInChildren () 
end

function BackdoorDialog:GetComponentsInChildren (results) 
end

function BackdoorDialog:GetComponentInParent (t) 
end

function BackdoorDialog:GetComponentInParent () 
end

function BackdoorDialog:GetComponentsInParent (t) 
end

function BackdoorDialog:GetComponentsInParent (t, includeInactive) 
end

function BackdoorDialog:GetComponentsInParent (includeInactive) 
end

function BackdoorDialog:GetComponentsInParent (includeInactive, results) 
end

function BackdoorDialog:GetComponentsInParent () 
end

function BackdoorDialog:GetComponents (type) 
end

function BackdoorDialog:GetComponents (type, results) 
end

function BackdoorDialog:GetComponents (results) 
end

function BackdoorDialog:GetComponents () 
end

function BackdoorDialog:CompareTag (tag) 
end

function BackdoorDialog:SendMessageUpwards (methodName, value, options) 
end

function BackdoorDialog:SendMessageUpwards (methodName, value) 
end

function BackdoorDialog:SendMessageUpwards (methodName) 
end

function BackdoorDialog:SendMessageUpwards (methodName, options) 
end

function BackdoorDialog:SendMessage (methodName, value, options) 
end

function BackdoorDialog:SendMessage (methodName, value) 
end

function BackdoorDialog:SendMessage (methodName) 
end

function BackdoorDialog:SendMessage (methodName, options) 
end

function BackdoorDialog:BroadcastMessage (methodName, parameter, options) 
end

function BackdoorDialog:BroadcastMessage (methodName, parameter) 
end

function BackdoorDialog:BroadcastMessage (methodName) 
end

function BackdoorDialog:BroadcastMessage (methodName, options) 
end

function BackdoorDialog:ToString () 
end

function BackdoorDialog:GetInstanceID () 
end

function BackdoorDialog:GetHashCode () 
end

function BackdoorDialog:Equals (other) 
end

function BackdoorDialog:GetType () 
end

