ModUIUtils = {}

function ModUIUtils.Init () 
end

function ModUIUtils.GetChild (parent, childName) 
end

function ModUIUtils.GetChild (parent, childName) 
end

function ModUIUtils.ChangePos (rect, x, y) 
end

function ModUIUtils.ChangePos (t, x, y) 
end

function ModUIUtils.ChangeSize (rect, width, height) 
end

function ModUIUtils.ChangeSize (t, width, height) 
end

function ModUIUtils.ChangeSize (t, width, height) 
end

function ModUIUtils.BindingButtonClick (parent, onUIEvent) 
end

function ModUIUtils.BindingButtonClick (parent, preventDoubleClickTime, onUIEvent) 
end

function ModUIUtils.AddClick (go, onUIEvent) 
end

function ModUIUtils.AddClick (go, preventDoubleClickTime, onUIEvent) 
end

function ModUIUtils.RemoveClick (go) 
end

function ModUIUtils.AddTouchEvent (go, onUIEvent) 
end

function ModUIUtils.RemoveTouchEvent (go) 
end

function ModUIUtils:Equals (obj) 
end

function ModUIUtils:GetHashCode () 
end

function ModUIUtils:GetType () 
end

function ModUIUtils:ToString () 
end

