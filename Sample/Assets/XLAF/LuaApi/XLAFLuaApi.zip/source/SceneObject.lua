SceneObject = {}

sceneName = nil
function SceneObject:EnableUIListener () 
end

function SceneObject:DisableUIListener () 
end

function SceneObject:ChangeAlpha (alphaValue) 
end

function SceneObject:RestoreStatus () 
end

function SceneObject:AddPopupBackground (bgAlphaValue) 
end

function SceneObject:Equals (obj) 
end

function SceneObject:GetHashCode () 
end

function SceneObject:GetType () 
end

function SceneObject:ToString () 
end

